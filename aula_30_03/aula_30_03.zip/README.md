# Exercício 30/03/2022

Crie uma página em PHP que calcula o salário líquido de um funcionário. O funcionário deve fornecer as seguintes informações: nome, idade, salário, vale alimentação e vale transporte.

Condições:

- Salário menor que R$2.000,00 é isento de imposto
- Salário entre R$2.000 a menor do que R$3.500 tem 7,5% de imposto
- Salário entre R$3.500 a menor do que R$5.000 tem 10% de imposto
- Salário entre R$5.000 a menor do que R$7.000 tem 12,5% de imposto
- Salário maior do que R$7.000,00 tem 15% de imposto
